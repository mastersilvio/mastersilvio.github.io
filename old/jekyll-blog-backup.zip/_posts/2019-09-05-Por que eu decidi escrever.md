---
title: 'Por que eu decidi escrever'
published: true
tags: [Tecnologia, Escrita]
lang: pt
translation_key: why-i-decided-to-write
---

Eu decidi escrever porque quero organizar as minhas ideias e compartilhar um pouco sobre a minha vida pessoal e profissional.

Escrevo não para agradar as pessoas, mas escrevo pra mim, para o meu eu do futuro.

Quanto mais o tempo passa, mais mudamos, evoluímos, trocamos de ideia e nos amadurecemos. Acredito que nossa essência, aquela característica que nos faz únicos, essa nunca muda, mas o restante sim.

Comunicar com você mesmo em diferentes épocas é a melhor maneira de se compreender e evoluir.

Essas serão as minhas conversas com o meu "eu" do futuro.
