---
title: 'Why I Decided to Write'
published: true
tags: [Technology, Writing]
lang: en
translation_key: why-i-decided-to-write
---

I decided to write because I want to organize my ideas and share a bit about my personal and professional life.

I don't write to please people, but I write for myself, for my future self.

The more time passes, the more we change, evolve, change our minds, and mature. I believe that our essence, that characteristic that makes us unique, never changes, but everything else does.

Communicating with yourself at different times is the best way to understand and evolve.

These will be my conversations with my future "self".
