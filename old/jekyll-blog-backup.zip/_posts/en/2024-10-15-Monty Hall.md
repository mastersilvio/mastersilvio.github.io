---
title: 'Monty Hall'
published: false
tags: [Technology, Probability, Mathematics]
lang: en
translation_key: monty-hall
permalink: /en/monty-hall
---

## Introduction

The Monty Hall Paradox is a probability problem that confuses many people. It became popular with the show "Let's Make a Deal," hosted by Monty Hall. The question is as follows: you participate in a game with three doors. Behind one of them is a car and behind the other two are goats. You choose a door, but the host, who knows what is behind each door, opens one of the other two, revealing a goat. Then, he gives you the option to switch doors or keep your original choice. What should you do to increase your chances of winning the car?

The surprising solution is that, to maximize your chances of winning, you should switch doors. In this blog post, let's understand why and simulate the Monty Hall Paradox with Ruby.

The Paradox Explained

Here is the mathematical summary behind the problem:

1. When you choose a door, the probability of you picking the car is 1/3, and the probability of being wrong is 2/3.
2. When Monty reveals a goat behind one of the other two doors, the probability that your original door is correct does not change (still 1/3).
3. The remaining unchosen door now has a 2/3 chance of being correct because Monty always reveals a goat.

Therefore, switching doors increases your chances of winning to 2/3!

