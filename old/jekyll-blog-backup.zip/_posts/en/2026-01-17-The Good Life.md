---
title: 'The Good Life'
published: true
tags: [Reflection, Philosophy, Life]
lang: en
translation_key: good-life
---

Monday afternoon I saw an elderly couple in the mall parking lot.

I found it so beautiful to watch them walk to the car.

I reflected on life.

Is a happy life really a life full of possessions, expensive cars and mansions?

Or a simple walk with your wife at the mall on a Monday afternoon?

Is expensive food really good?

Or is freshly brewed coffee and warm cheese bread more delicious?

This is the good life: simple, free and anonymous.
