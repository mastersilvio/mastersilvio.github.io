---
title: 'O Cálculo Daquilo que Não Tem Valor'
published: true
tags: [Pensamentos, Filosofia, Matemática]
lang: pt
translation_key: calculation-no-value
---

Sempre fui uma pessoa que ama calcular.

Fui professor de matemática por 8 anos e sou programador há mais de 10 anos e minha vida sempre foi calcular.

Sempre soube que aquilo que pode ser medido, pode ser melhorado. E que podemos atribuir um número ou medida para praticamente qualquer coisa.

Mas será mesmo? Será que podemos mensurar tudo e que tudo tem o seu valor?

Mesmo sendo apaixonado por números aprendi que existem coisas que são incomensuráveis.

Que momentos com os filhos não tem valor um valor paupável e que é impossível medi-los.

Que pessoas se vão e as memórias de momentos vividos não tem preço.

Que as fotos e vídeos antes vistos como desnecessários hoje valem muito.

E que a felicidade não pode ser medida.

