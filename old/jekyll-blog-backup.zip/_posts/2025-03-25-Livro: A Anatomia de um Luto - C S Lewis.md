---
title: 'Livro: A Anatomia de um Luto - C S Lewis'
published: true
tags: [Livros]
lang: pt
translation_key: grief-observed
---

### Review e considerações sobre o momento da leitura do livro

Eu comecei a ler esse livro logo após a morte do meu querido paizinho.

Até o momento não consegui escrever nada sobre isso e estou passando pelo processo de luto.

O pouco que eu escrevi foi no Instagram com fotos e vídeos dele em momentos especiais.

Esse livro do C S Lewis fala da sua falecida esposa e trás a reflexão quanto ao luto.

Um dos pontos que mais me marcou foi que ele, assim como eu, questionou a existência de Deus e o porquê de está passando por isso.

Hoje estou no hospital com a minha filha na UTI desde que nasceu, há 64 dias.

Além do sofrimento por estar passando por essa situação, perdi meu pai há 3 semanas.

Eu sei que todos passam por dificuldades e alguns passam por dificuldades maiores ainda e sei que isso é um processo.

No caso do meu pai, é um processo de luto e sou grato pelos seus 77 anos de vida e por termos feito tanta coisa juntos.

Outro ponto interessante do livro é sobre o questionamento se encontraremos novamente os entes que partiram.

Eu acredito que sim e que poderemos conversar sobre tudo isso e ver que essa passagem foi algo simples comparado a nova realidade que teremos.
